public class Main {
    public static void main(String[] args) {

        System.out.println("Hello World!");
        System.out.println("My name is Shogo Adebayo");
        System.out.println("I am a Software Tester");
        System.out.println("I am passionate about Tech and Tech programs");
        System.out.println("This is my first Java Code");
        System.out.println("Today is March 14, 2023");
        System.out.println(2023);
    }

}